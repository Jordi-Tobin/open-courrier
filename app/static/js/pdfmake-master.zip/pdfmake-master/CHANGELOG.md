# Changelog

## Unreleased

- Port code base to ES6+
- Unify interface for node and browser **(breaking change)**
- Change including virtual font storage in client-side **(breaking change)**
