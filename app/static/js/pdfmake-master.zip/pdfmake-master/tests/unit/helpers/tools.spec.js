//const assert = require('assert');

describe('helpers/tools', function () {

	// TODO

});
