//var assert = require('assert');

describe('TextDecorator', function () {

	// TODO

});
