module.exports = require('./index').default;
