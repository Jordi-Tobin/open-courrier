describe('Select - type - select-checkbox', function() {
	let table;

	dt.libs({
		js: ['jquery', 'datatables', 'select'],
		css: ['datatables', 'select']
	});

	describe('Functional tests', function() {
		dt.html('basic');
		it('No info', function(done) {
			var cols = dt.getTestColumns();
			cols[5].data = null;
			cols[5].defaultContent = '';

			console.log(cols);

			table = $('#example').DataTable({
				ajax: '/base/test/data/data.txt',
				select: {
					style: 'multi',
					selector: 'td:last-child'
				},
				columns: cols,
				order: [5, 'desc'],
				columnDefs: [
					{
						orderable: true,
						className: 'select-checkbox',
						targets: -1,
						orderDataType: 'select-checkbox'
					}
				],
				initComplete: function() {
					done();
				}
			});
		});
		it('Combination of selections - multiple', function() {
			$('tbody tr:eq(2) td:eq(5)').click();
			$('tbody tr:eq(7) td:eq(5)').click();
			table.draw();

			expect($('tbody tr:eq(0) td:eq(0)').text()).toBe('Ashton Cox');
			expect($('tbody tr:eq(1) td:eq(0)').text()).toBe('Rhona Davidson');
			expect($('tbody tr:eq(2) td:eq(0)').text()).toBe('Tiger Nixon');
		});
	});
});
